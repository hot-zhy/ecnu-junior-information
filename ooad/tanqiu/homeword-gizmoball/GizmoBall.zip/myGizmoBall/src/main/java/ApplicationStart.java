import UI.GamePanel;

/**
     * 游戏总启动类
 */
public class ApplicationStart {
    public static void main(String[] args) {
        GamePanel myFrame = new GamePanel();
    }
}
