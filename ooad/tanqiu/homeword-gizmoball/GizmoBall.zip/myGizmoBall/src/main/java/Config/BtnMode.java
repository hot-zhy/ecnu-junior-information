package Config;

/**
 * 枚举类型，列举当前选择的是组件还是工具
 */
public enum BtnMode {
    Shape, Tool
}
