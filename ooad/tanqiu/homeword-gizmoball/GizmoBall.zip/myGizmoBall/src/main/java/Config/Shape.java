package Config;

/**
 * 组件枚举类型
 */
public enum Shape {
    Finger, Ball, Absorber, Triangle, Circle, Square, Track, Paddle, Corner, Bound
}
