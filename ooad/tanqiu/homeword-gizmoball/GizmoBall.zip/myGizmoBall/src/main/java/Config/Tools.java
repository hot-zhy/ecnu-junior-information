package Config;

/**
 * 工具枚举类型
 */
public enum Tools {
    Rotate, Remove, ZoomIn, ZoomOut
}
