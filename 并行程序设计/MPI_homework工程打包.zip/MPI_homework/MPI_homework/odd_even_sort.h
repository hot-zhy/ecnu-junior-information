#pragma once
//local��ĺ���
void Usage(char* program);
void Print_list(int local_A[], int local_n, int rank);
void Merge_low(int local_A[], int temp1[], int temp2[],int local_n);
void Merge_high(int local_A[], int temp1[], int temp2[],int local_n);
void random_list(int local_A[], int local_n, int my_rank);
int  Compare(const void* a_p, const void* b_p);
//�漰��ͨ�ŵĺ���
void Get_args(int argc, char* argv[], int* global_n_p, int* local_n_p,char* gi_p, int my_rank, int p, MPI_Comm comm);
void Sort(int local_A[], int local_n, int my_rank,int p, MPI_Comm comm);
void Odd_even_iteration(int local_A[], int temp_B[], int temp_C[],int local_n, int phase, int even_partner, int odd_partner, int my_rank, int p, MPI_Comm comm);
void Print_Unsorted_Vector(int local_A[], int local_n,int my_rank, int p, MPI_Comm comm);
void Print_Sorted_Vector(int local_A[], int local_n, int my_rank,int p, MPI_Comm comm);
void Get_Input(int local_A[], int local_n, int my_rank, int p, MPI_Comm comm);
